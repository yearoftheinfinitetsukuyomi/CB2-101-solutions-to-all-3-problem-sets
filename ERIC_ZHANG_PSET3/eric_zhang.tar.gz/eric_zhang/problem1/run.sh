#!/usr/bin/Rscript
problem1.R ../9660.tsv.gz BRCA1
